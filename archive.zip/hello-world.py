# Hello world

def main():
    print("Hello world")
    # name = input("What's your name? ")
    # print("Nice to meet you, ", name)

if __name__ == "__main__":
    main()
